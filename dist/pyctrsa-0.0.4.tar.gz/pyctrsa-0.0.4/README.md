# PyCTRSA
A Python toolbox for Cross-Temporal Representation Similarity Analysis on EEG/MEG data
